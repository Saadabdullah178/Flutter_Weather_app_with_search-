import 'dart:async';
import 'dart:convert';

import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:connection_notifier/connection_notifier.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:geocoder/geocoder.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:location/location.dart';


class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}
class _HomePageState extends State<HomePage> {

String lat="";
String lon="";
String demo_temp="";
String demo_feels_like="";
String demo_temp_min="";
String demo_temp_max="";
String demo_pressure="";
String demo_humidity="";
String demo_sea_level="";
String demo_grnd_level="";
  DateTime now = DateTime.now();
  String city="";
  String Key="04f9483bec94cdbb20d407899e65815b";
  late LocationData myLocation;
  bool isDarkMode=true;
  //city name
  int currTemp = 0; // current temperature
  int maxTemp = 0; // today max temperature
  int minTemp = 0;
  double feels_like=0.0;
  double pressure=0.0;
  double sea_level=0.0;
  double grnd_level=0.0;
  double humidity=0.0;
  double temp_kf=0.0;
  double speed=0.0;
  String weather="";
  double chance=0.0;
  String current_hour="";
  String onlinehour="";
  int live_index=0;

String upcoming1="";
String upcoming2="";
String upcoming3="";
String upcoming4="";
String upcoming5="";
String upcoming6="";
String upcoming7="";
String upcoming8="";
String upcoming9="";

int tem1=0;
int speed1=0;
int persent1=0;

int tem2=0;
int speed2=0;
int persent2=0;

int tem3=0;
int speed3=0;
int persent3=0;

int tem4=0;
int speed4=0;
int persent4=0;

int tem5=0;
int speed5=0;
int persent5=0;

int tem6=0;
int speed6=0;
int persent6=0;

int tem7=0;
int speed7=0;
int persent7=0;

int tem8=0;
int speed8=0;
int persent8=0;
bool search1=false;
int tem9=0;
int speed9=0;
int persent9=0;
String current_day="";
String day1="";
String day2="";
String day3="";
String day4="";
String day5="";
String day6="";
String day7="";

int tem_1=0;
int tem_2=0;
int tem_3=0;
int tem_4=0;
int tem_5=0;
int tem_6=0;

int check1=10;
weak_day(){
  int current=now.weekday.toInt();
  for(int i=0;i<=6;i++){
    current++;
    if(current==1 || current==8){
      current_day="Mon";
    }
    else if(current==2 || current==9){
      current_day="Tue";
    }
    else if(current==3 || current==10){
      current_day="Wed";
    }
   else if(current==4 || current==11){
      current_day="Thu";
    }
   else if(current==5 || current==12){
      current_day="Fri";
    }
   else if(current==6 || current==13){
      current_day="Sat";
    }
    else if(current==7 || current==14 ){
      current_day="Sun";
    }
    else{}
    if(i==0){day1=current_day;}
    if(i==1){day2=current_day;}
    if(i==2){day3=current_day;}
    if(i==3){day4=current_day;}
    if(i==4){day5=current_day;}
    if(i==5){day6=current_day;}
    if(i==6){day7=current_day;}
  }
  print(day7);
}


  @override
  void initState() {
    getUserLocation();
    // TODO: implement initState
    super.initState();
  }
  void _getWeatherData_x_y() async {
    String apiUrl = "https://api.openweathermap.org/data/2.5/forecast?q=${city}&appid=${Key}";

    try {
      http.Response response = await http.get(Uri.parse(apiUrl));
      if (response.statusCode == 200) {
        var  result = jsonDecode(response.body);
        Timer(Duration(seconds: 3), () {
          lat=result["city"]["coord"]["lat"].toString();
          lon=result["city"]["coord"]["lon"].toString();
          _getWeatherData();
        });
      } else {
        print("Error: ${response.statusCode}");
      }
    } catch (e) {
      print("Exception caught: $e");
    }
  }
  void _getWeatherData() async {
    String apiUrl =
        "https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=04f9483bec94cdbb20d407899e65815b";
    try {
      http.Response response = await http.get(Uri.parse(apiUrl));
      if (response.statusCode == 200) {
       var  result = jsonDecode(response.body);

        demo_temp=(result["main"]["temp"].toString());
       demo_feels_like=(result["main"]["feels_like"].toString());
       demo_temp_min=(result["main"]["temp_min"].toString());
       demo_temp_max=(result["main"]["temp_max"].toString());
       demo_pressure=(result["main"]["pressure"].toString());
       demo_humidity=(result["main"]["humidity"].toString());
       demo_sea_level=(result["main"]["sea_level"].toString());
       demo_grnd_level=(result["main"]["grnd_level"].toString());
         print(result["main"]);
       _getWeatherData_live();

      } else {
        print("Error: ${response.statusCode}");
      }
    } catch (e) {
      print("Exception caught: $e");
    }
  }

  void _getWeatherData_live() async {
    String apiUrl = "https://api.openweathermap.org/data/2.5/forecast?q=${city}&appid=${Key}";

    try {
      http.Response response = await http.get(Uri.parse(apiUrl));
      if (response.statusCode == 200) {
        var  result = jsonDecode(response.body);
        setState(() {
          Timer(Duration(seconds: 0), () {
            live_index=0;
            for(int i=0;i<38;i++){
              if(double.parse(result["list"][i]["main"]["temp"].toString())>=double.parse(demo_temp)-0.10 && double.parse(result["list"][i]["main"]["temp"].toString())<=double.parse(demo_temp)+0.1  &&
                  double.parse(result["list"][i]["main"]["pressure"].toString())>=double.parse(demo_temp)-0.10 && double.parse(result["list"][i]["main"]["pressure"].toString())<=double.parse(demo_pressure)+0.10)
              {
                  live_index=i;
                  print(live_index);
                  double convert=double.parse(result["list"][live_index]["main"]["temp"].toString());
                  double convert_min=double.parse(result["list"][live_index]["main"]["temp_min"].toString());
                  double convert_mix=double.parse(result["list"][live_index]["main"]["temp_max"].toString());
                  double convert_feels_like=double.parse(result["list"][live_index]["main"]["feels_like"].toString());
                  double convert_pressure=double.parse(result["list"][live_index]["main"]["pressure"].toString());
                  double convert_sea_level=double.parse(result["list"][live_index]["main"]["sea_level"].toString());
                  double convert_grnd_level=double.parse(result["list"][live_index]["main"]["grnd_level"].toString());
                  double convert_humidity=double.parse(result["list"][live_index]["main"]["humidity"].toString());
                  double convert_temp_kf=double.parse(result["list"][live_index]["main"]["temp_kf"].toString());
                  currTemp=(convert-273.15).toInt();
                  minTemp=(convert_min-273.15).toInt();
                  maxTemp=(convert_mix-273.15).toInt();
                  feels_like=(convert_feels_like-273.15);
                  pressure=convert_pressure;
                  sea_level=convert_sea_level;
                  grnd_level=convert_grnd_level;
                  humidity=convert_humidity;
                  temp_kf=convert_temp_kf;
                  weather=result["list"][live_index]["weather"][0]["main"].toString();
                  speed=double.parse(result["list"][live_index]["wind"]["speed"].toString());
                  chance=100-double.parse(result["list"][live_index]["clouds"]["all"].toString());
                 i=38;

              }
              else{}
            }

            String time1=result["list"][live_index+1]["dt_txt"];
            String time2=result["list"][live_index+2]["dt_txt"];
            String time3=result["list"][live_index+3]["dt_txt"];
            String time4=result["list"][live_index+4]["dt_txt"];
            String time5=result["list"][live_index+5]["dt_txt"];
            String time6=result["list"][live_index+6]["dt_txt"];
            String time7=result["list"][live_index+7]["dt_txt"];
            String time8=result["list"][live_index+8]["dt_txt"];
            String time9=result["list"][live_index+9]["dt_txt"];
            upcoming1="${time1[11]}${time1[12]}${time1[13]}${time1[14]}${time1[15]}";
            upcoming2="${time2[11]}${time2[12]}${time2[13]}${time2[14]}${time2[15]}";
            upcoming3="${time3[11]}${time3[12]}${time3[13]}${time3[14]}${time3[15]}";
            upcoming4="${time4[11]}${time4[12]}${time4[13]}${time4[14]}${time4[15]}";
            upcoming5="${time5[11]}${time5[12]}${time5[13]}${time5[14]}${time5[15]}";
            upcoming6="${time6[11]}${time6[12]}${time6[13]}${time6[14]}${time6[15]}";
            upcoming7="${time7[11]}${time7[12]}${time7[13]}${time7[14]}${time7[15]}";
            upcoming8="${time8[11]}${time8[12]}${time8[13]}${time8[14]}${time8[15]}";
            upcoming9="${time9[11]}${time9[12]}${time9[13]}${time9[14]}${time9[15]}";

            tem1= (double.parse(result["list"][live_index+1]["main"]["temp"].toString())-273.15).toInt();
            speed1= double.parse(result["list"][live_index+1]["wind"]["speed"].toString()).toInt();
            persent1= (100-double.parse(result["list"][live_index+1]["clouds"]["all"].toString())).toInt();

            tem2= (double.parse(result["list"][live_index+2]["main"]["temp"].toString())-273.15).toInt();
            speed2= double.parse(result["list"][live_index+2]["wind"]["speed"].toString()).toInt();
            persent2= (100-double.parse(result["list"][live_index+2]["clouds"]["all"].toString())).toInt();

            tem3= (double.parse(result["list"][live_index+3]["main"]["temp"].toString())-273.15).toInt();
            speed3= double.parse(result["list"][live_index+3]["wind"]["speed"].toString()).toInt();
            persent3= (100-double.parse(result["list"][live_index+3]["clouds"]["all"].toString())).toInt();

            tem4= (double.parse(result["list"][live_index+4]["main"]["temp"].toString())-273.15).toInt();
            speed4= double.parse(result["list"][live_index+4]["wind"]["speed"].toString()).toInt();
            persent4= (100-double.parse(result["list"][live_index+4]["clouds"]["all"].toString())).toInt();

            tem5= (double.parse(result["list"][live_index+5]["main"]["temp"].toString())-273.15).toInt();
            speed5= double.parse(result["list"][live_index+5]["wind"]["speed"].toString()).toInt();
            persent5= (100-double.parse(result["list"][live_index+5]["clouds"]["all"].toString())).toInt();

            tem6= (double.parse(result["list"][live_index+6]["main"]["temp"].toString())-273.15).toInt();
            speed6= double.parse(result["list"][live_index+6]["wind"]["speed"].toString()).toInt();
            persent6= (100-double.parse(result["list"][live_index+6]["clouds"]["all"].toString())).toInt();

            tem7= (double.parse(result["list"][live_index+7]["main"]["temp"].toString())-273.15).toInt();
            speed7= double.parse(result["list"][live_index+7]["wind"]["speed"].toString()).toInt();
            persent7= (100-double.parse(result["list"][live_index+7]["clouds"]["all"].toString())).toInt();

            tem8= (double.parse(result["list"][live_index+8]["main"]["temp"].toString())-273.15).toInt();
            speed8= double.parse(result["list"][live_index+8]["wind"]["speed"].toString()).toInt();
            persent8= (100-double.parse(result["list"][live_index+8]["clouds"]["all"].toString())).toInt();

            tem9= (double.parse(result["list"][live_index+9]["main"]["temp"].toString())-273.15).toInt();
            speed9= double.parse(result["list"][live_index+9]["wind"]["speed"].toString()).toInt();
            persent9= (100-double.parse(result["list"][live_index+9]["clouds"]["all"].toString())).toInt();






           // int a=double.parse(result["list"][live_index]["main"]["temp"].toString()).toInt();
            int check=0;
            int a=0;
            for(int i=0;i<=38;i++){
              String index=result["list"][i]["dt_txt"];
              String s="${index[8]}${index[9]}";
              int convert=double.parse(s.toString()).toInt();
              if(check!=convert){
                a++;
                if(a==1){
                  tem_1=(double.parse(result["list"][i]["main"]["temp_max"].toString())-273.15).toInt();
                  print(result["list"][i]["main"]["temp_max"]);
                //  print(now.weekday);

                }
                else if(a==2){
                  tem_2=(double.parse(result["list"][i]["main"]["temp_max"].toString())-273.15).toInt();
                }
                else if(a==3){
                  tem_3=(double.parse(result["list"][i]["main"]["temp_max"].toString())-273.15).toInt();
                }
                else if(a==4){
                  tem_4=(double.parse(result["list"][i]["main"]["temp_max"].toString())-273.15).toInt();
                }
                else if(a==5){
                  tem_5=(double.parse(result["list"][i]["main"]["temp_max"].toString())-273.15).toInt();
                }
                else {
                  tem_6=(double.parse(result["list"][i]["main"]["temp_max"].toString())-273.15).toInt();
                }

               // print(result["list"][i]["dt_txt"]);
                check=convert;
              }

            }
            weak_day();

           // print(result["list"][37]["dt_txt"]);

          });

         // print(int.parse(demo_temp));
         // print(result["list"][0]["main"]["temp"].toString());
         // current_hour=now.hour.toString();
        //  live_index=0;
        //  String index=result["list"][live_index]["dt_txt"].toString();
        //  onlinehour="${index[11]}${index[12]}";


         // print(result["list"][0]["dt_txt"]);
       //   print(result["city"]["coord"]["lat"]);
      //    print(result["city"]["coord"]["lon"]);
        });
      } else {
        print("Error: ${response.statusCode}");
      }
    } catch (e) {
      print("Exception caught: $e");
    }
  }

  getUserLocation() async {//call this async method from whereever you need

    String error;
    Location location = new Location();
    try {
      myLocation = await location.getLocation();
    } on PlatformException catch (e) {
      if (e.code == 'PERMISSION_DENIED') {
        error = 'please grant permission';
        print(error);
      }
      if (e.code == 'PERMISSION_DENIED_NEVER_ASK') {
        error = 'permission denied- please enable it from app settings';
        print(error);
      }
      myLocation;
    }
    var currentLocation = myLocation;
    final coordinates = new Coordinates(
        myLocation.latitude, myLocation.longitude);
    var addresses = await Geocoder.local.findAddressesFromCoordinates(
        coordinates);
    var first = addresses.first;
 //   print(' ${first.locality}, ${first.adminArea},${first.subLocality}, ${first.subAdminArea},${first.addressLine}, ${first.featureName},${first.thoroughfare}, ${first.subThoroughfare}');
  //  print( first.coordinates.latitude);
 //   print( first.coordinates.longitude);
   print(first.locality);
    city=first.locality;
    _getWeatherData_x_y();


    return first;
  }

  Future<Null> _refreshLocalGallery() async{
    //getUserLocation();
   // _getWeatherData();
   // _getWeatherData_live();
    _getWeatherData_x_y();
    print('refreshing stocks...');

  }

TextEditingController _searchController = TextEditingController();

  @override
  Widget build(BuildContext context) {
  if(currTemp==0 || maxTemp==0|| minTemp==0){
  Timer(Duration(seconds: 1), () {
    _getWeatherData_x_y();
  });
  }
    IconData Weather_icon(){
      var icon=FontAwesomeIcons.cloud;
      if(weather=="Rain"){
        icon=FontAwesomeIcons.cloudRain;
      }
      else if(weather=="Cloud"){
        icon=FontAwesomeIcons.cloud;
      }
      else{
        icon=FontAwesomeIcons.sun;
      }
      return icon;
    }
    String cityName = city;

    // today min temperature
    Size size = MediaQuery.of(context).size;
    var brightness = MediaQuery.of(context).platformBrightness;

   // bool isDarkMode = brightness == Brightness.light;
    return Scaffold(
appBar: AppBar(
  backgroundColor:isDarkMode ? Colors.black:  Colors.white ,
  title:Padding(

  padding: const EdgeInsets.all(8.0),
  child: Container(
    decoration: BoxDecoration(color: isDarkMode ?  Colors.white70:  Colors.white,borderRadius: BorderRadius.circular(30)),
    child: TextField(
      onChanged: (value){
        setState(() {
          if(_searchController!=""){
            search1=true;
          }
          else{
            search1=false;
          }
        });
      },
      autofocus: false,
      style: TextStyle( height: 0.5,),
 controller: _searchController,
      decoration: InputDecoration(

        filled: true,
        hintStyle: TextStyle( color: Colors.black26),
        hintText: 'Search...',
// Add a clear button to the search bar
        suffixIcon: IconButton(
          icon: search1?InkWell(child: Icon(Icons.send)):Text(""),
          onPressed: () {
            city=_searchController.text;
            _getWeatherData_x_y();
          } ,
        ),
// Add a search icon or button to the search bar
        prefixIcon: IconButton(
          icon: Icon(Icons.search,color: Colors.black26,),
          onPressed: () {
            print("object");
// Perform the search here
          },
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(30.0),
        ),
      ),

    ),),
),),
      body: Center(
        child: Stack(
          children: [
            Container(
              height: size.height,
              width: size.height,
              decoration: BoxDecoration(
                color: isDarkMode ? Colors.black : Colors.white,
              ),
              child: SafeArea(
                child: RefreshIndicator(
                  onRefresh: _refreshLocalGallery,
                  child: SingleChildScrollView(
                    physics: const AlwaysScrollableScrollPhysics(),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: EdgeInsets.symmetric(
                                vertical: size.height * 0.01,
                                horizontal: size.width * 0.05,
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(""),
                                  Align(
                                    child: Text(
                                      '', //TODO: change app name
                                      style: GoogleFonts.questrial(
                                        color: isDarkMode
                                            ? Colors.white
                                            : const Color(0xff1D1617),
                                        fontSize: size.height * 0.02,
                                      ),
                                    ),
                                  ),
                                  InkWell(
                                    onTap: (){setState(() {
                                      if(isDarkMode){
                                        isDarkMode=false;
                                      }
                                      else{
                                        isDarkMode=true;
                                      }

                                    });},
                                    child: SizedBox(
                                      width: 40,
                                      child: FaIcon(
                                        FontAwesomeIcons.lightbulb,
                                        color: isDarkMode ? Colors.white : Colors.black,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.only(
                                top: size.height * 0.03,
                              ),
                              child: Align(
                                child: Text(
                                  cityName,
                                  style: GoogleFonts.questrial(
                                    color: isDarkMode ? Colors.white : Colors.black,
                                    fontSize: size.height * 0.06,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.only(
                                top: size.height * 0.005,
                              ),
                              child: Align(
                                child: Text(
                                  'Today', //day
                                  style: GoogleFonts.questrial(
                                    color:
                                        isDarkMode ? Colors.white54 : Colors.black54,
                                    fontSize: size.height * 0.035,
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.only(
                                top: size.height * 0.03,
                              ),
                              child: Align(
                                child: Text(
                                  '$currTemp˚C', //curent temperature
                                  style: GoogleFonts.questrial(
                                    color: currTemp <= 0
                                        ? Colors.blue
                                        : currTemp > 0 && currTemp <= 15
                                            ? Colors.indigo
                                            : currTemp > 15 && currTemp < 30
                                                ? Colors.deepPurple
                                                : Colors.pink,
                                    fontSize: size.height * 0.13,
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.only(
                                top: size.height * 0.005,
                              ),
                              child: Align(
                                child:  SizedBox(
                                  height: 20,
                                  child: AnimatedTextKit(
                                        repeatForever: true,
                                        animatedTexts: [
                                          FadeAnimatedText('Feels like ${feels_like}',textStyle: GoogleFonts.questrial(
                                            color:
                                            isDarkMode ? Colors.purple : Colors.deepPurple,
                                            fontSize: size.height * 0.02,
                                          ),),
                                          FadeAnimatedText('Pressure ${pressure}',textStyle: GoogleFonts.questrial(
                                            color:
                                            isDarkMode ? Colors.purple : Colors.deepPurple,
                                            fontSize: size.height * 0.02,
                                          )),
                                          FadeAnimatedText('Sea level ${sea_level}',textStyle: GoogleFonts.questrial(
                                            color:
                                            isDarkMode ? Colors.purple : Colors.deepPurple,
                                            fontSize: size.height * 0.02,
                                          )),
                                          FadeAnimatedText('Grnd_level ${grnd_level}',textStyle: GoogleFonts.questrial(
                                            color:
                                            isDarkMode ? Colors.purple : Colors.deepPurple,
                                            fontSize: size.height * 0.02,
                                          )),
                                          FadeAnimatedText('humidity ${humidity}',textStyle: GoogleFonts.questrial(
                                            color:
                                            isDarkMode ? Colors.purple : Colors.deepPurple,
                                            fontSize: size.height * 0.02,
                                          )),
                                          FadeAnimatedText('Temp_kf ${temp_kf}',textStyle: GoogleFonts.questrial(
                                            color:
                                            isDarkMode ? Colors.purple : Colors.deepPurple,
                                            fontSize: size.height * 0.02,
                                          ))
                                        ],
                                        onTap: () {
                                          print("Tap Event");
                                        },
                                      ),
                                ),


                                ),
                              ),


                            Padding(
                              padding:
                                  EdgeInsets.symmetric(horizontal: size.width * 0.25),
                              child: Divider(
                                color: isDarkMode ? Colors.white : Colors.black,
                              ),
                            ),

                            Padding(
                              padding: EdgeInsets.only(
                                top: size.height * 0.005,
                              ),
                              child: Align(
                                child: Text(
                                  '${weather}', // weather
                                  style: GoogleFonts.questrial(
                                    color:
                                        isDarkMode ? Colors.white54 : Colors.black54,
                                    fontSize: size.height * 0.03,
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.only(
                                top: size.height * 0.03,
                                bottom: size.height * 0.01,
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    '$minTemp˚C', // min temperature
                                    style: GoogleFonts.questrial(
                                      color: minTemp <= 0
                                          ? Colors.blue
                                          : minTemp > 0 && minTemp <= 15
                                              ? Colors.indigo
                                              : minTemp > 15 && minTemp < 30
                                                  ? Colors.deepPurple
                                                  : Colors.pink,
                                      fontSize: size.height * 0.03,
                                    ),
                                  ),
                                  Text(
                                    '/',
                                    style: GoogleFonts.questrial(
                                      color: isDarkMode
                                          ? Colors.white54
                                          : Colors.black54,
                                      fontSize: size.height * 0.03,
                                    ),
                                  ),
                                  Text(
                                    '$maxTemp˚C', //max temperature
                                    style: GoogleFonts.questrial(
                                      color: maxTemp <= 0
                                          ? Colors.blue
                                          : maxTemp > 0 && maxTemp <= 15
                                              ? Colors.indigo
                                              : maxTemp > 15 && maxTemp < 30
                                                  ? Colors.deepPurple
                                                  : Colors.pink,
                                      fontSize: size.height * 0.03,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.symmetric(
                                horizontal: size.width * 0.05,
                              ),
                              child: Container(
                                decoration: BoxDecoration(
                                  borderRadius: const BorderRadius.all(
                                    Radius.circular(10),
                                  ),
                                  color: isDarkMode
                                      ? Colors.white.withOpacity(0.05)
                                      : Colors.black.withOpacity(0.05),
                                ),
                                child: Column(
                                  children: [
                                    Align(
                                      alignment: Alignment.centerLeft,
                                      child: Padding(
                                        padding: EdgeInsets.only(
                                          top: size.height * 0.01,
                                          left: size.width * 0.03,
                                        ),
                                        child: Text(
                                          'Forecast for today',
                                          style: GoogleFonts.questrial(
                                            color: isDarkMode
                                                ? Colors.white
                                                : Colors.black,
                                            fontSize: size.height * 0.025,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),
                                    ),
                                    Padding(
                                      padding: EdgeInsets.all(size.width * 0.005),
                                      child: SingleChildScrollView(
                                        scrollDirection: Axis.horizontal,
                                        child: Row(
                                          children: [
                                            //TODO: change weather forecast from local to api get
                                            buildForecastToday(
                                              "Now", //hour
                                              currTemp, //temperature
                                              speed.toInt(), //wind (km/h)
                                              chance.toInt(), //rain chance (%)
                                              Weather_icon(), //weather icon
                                              size,
                                              isDarkMode,
                                            ),
                                            buildForecastToday(
                                              upcoming1,
                                              tem1,
                                              speed1,
                                              persent1,
                                              FontAwesomeIcons.longArrowAltDown,
                                              size,
                                              isDarkMode,
                                            ),
                                            buildForecastToday(
                                              upcoming2,
                                              tem2,
                                              speed2,
                                              persent2,
                                              FontAwesomeIcons.longArrowAltDown,
                                              size,
                                              isDarkMode,
                                            ),
                                            buildForecastToday(
                                              upcoming3,
                                              tem3,
                                              speed3,
                                              persent3,
                                              FontAwesomeIcons.longArrowAltDown,
                                              size,
                                              isDarkMode,
                                            ),
                                            buildForecastToday(
                                              upcoming4,
                                              tem4,
                                              speed4,
                                              persent4,
                                              FontAwesomeIcons.longArrowAltDown,
                                              size,
                                              isDarkMode,
                                            ),
                                            buildForecastToday(
                                              upcoming5,
                                              tem5,
                                              speed5,
                                              persent5,
                                              FontAwesomeIcons.longArrowAltDown,
                                              size,
                                              isDarkMode,
                                            ),
                                            buildForecastToday(
                                              upcoming6,
                                              tem6,
                                              speed6,
                                              persent6,
                                              FontAwesomeIcons.longArrowAltDown,
                                              size,
                                              isDarkMode,
                                            ),
                                            buildForecastToday(
                                              upcoming7,
                                              tem7,
                                              speed7,
                                              persent7,
                                              FontAwesomeIcons.longArrowAltDown,
                                              size,
                                              isDarkMode,
                                            ),
                                            buildForecastToday(
                                              upcoming8,
                                              tem8,
                                              speed8,
                                              persent8,
                                              FontAwesomeIcons.longArrowAltDown,
                                              size,
                                              isDarkMode,
                                            ),
                                            buildForecastToday(
                                              upcoming9,
                                              tem9,
                                              speed9,
                                              persent9,
                                              FontAwesomeIcons.longArrowAltDown,
                                              size,
                                              isDarkMode,
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.symmetric(
                                horizontal: size.width * 0.05,
                                vertical: size.height * 0.02,
                              ),
                              child: Container(
                                decoration: BoxDecoration(
                                  borderRadius: const BorderRadius.all(
                                    Radius.circular(10),
                                  ),
                                  color: Colors.white.withOpacity(0.05),
                                ),
                                child: Column(
                                  children: [
                                    Align(
                                      alignment: Alignment.centerLeft,
                                      child: Padding(
                                        padding: EdgeInsets.only(
                                          top: size.height * 0.02,
                                          left: size.width * 0.03,
                                        ),
                                        child: Text(
                                          '7-day forecast',
                                          style: GoogleFonts.questrial(
                                            color: isDarkMode
                                                ? Colors.white
                                                : Colors.black,
                                            fontSize: size.height * 0.025,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),
                                    ),
                                    Divider(
                                      color: isDarkMode ? Colors.white : Colors.black,
                                    ),
                                    Padding(
                                      padding: EdgeInsets.all(size.width * 0.005),
                                      child: Column(
                                        children: [
                                          //TODO: change weather forecast from local to api get
                                          buildSevenDayForecast(
                                            "Today", //day
                                            minTemp, //min temperature
                                            maxTemp, //max temperature
                                            Weather_icon(), //weather icon
                                            size,
                                            isDarkMode,
                                          ),
                                          buildSevenDayForecast(
                                            day1,
                                            tem_1-1,
                                            tem_1,
                                            FontAwesomeIcons.longArrowAltRight,
                                            size,
                                            isDarkMode,
                                          ),
                                          buildSevenDayForecast(
                                            day2,
                                            tem_2-1,
                                            tem_2,
                                            FontAwesomeIcons.longArrowAltRight,
                                            size,
                                            isDarkMode,
                                          ),
                                          buildSevenDayForecast(
                                            day3,
                                            tem_3-1,
                                            tem_3,
                                            FontAwesomeIcons.longArrowAltRight,
                                            size,
                                            isDarkMode,
                                          ),
                                          buildSevenDayForecast(
                                            day4,
                                            tem_4-1,
                                            tem_4,
                                            FontAwesomeIcons.longArrowAltRight,
                                            size,
                                            isDarkMode,
                                          ),
                                          buildSevenDayForecast(
                                            day5,
                                            tem_5-1,
                                            tem_5,
                                            FontAwesomeIcons.longArrowAltRight,
                                            size,
                                            isDarkMode,
                                          ),
                                          buildSevenDayForecast(
                                            day6,
                                            tem_6-1,
                                            tem_6,
                                            FontAwesomeIcons.longArrowAltRight,
                                            size,
                                            isDarkMode,
                                          ),

                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                ),

              ),
            ),
            ConnectionNotifierToggler(
              connected: Text(""),
              disconnected: Center(child: ClipRRect(
                  borderRadius: BorderRadius.circular(100.0),
                  child: Image.asset("assets/internet.gif"))),

            ),

          ],
        ),
      ),
    );
  }

  Widget buildForecastToday(String time, int temp, int wind, int rainChance,
      IconData weatherIcon, size, bool isDarkMode) {
    return Padding(
      padding: EdgeInsets.all(size.width * 0.025),
      child: Column(
        children: [
          Text(
            time,
            style: GoogleFonts.questrial(
              color: isDarkMode ? Colors.white : Colors.black,
              fontSize: size.height * 0.02,
            ),
          ),
          Row(
            children: [
              Padding(
                padding: EdgeInsets.symmetric(
                  vertical: size.height * 0.005,
                ),
                child: FaIcon(
                  weatherIcon,
                  color: isDarkMode ? Colors.white : Colors.black,
                  size: size.height * 0.03,
                ),
              ),
            ],
          ),
          Text(
            '$temp˚C',
            style: GoogleFonts.questrial(
              color: isDarkMode ? Colors.white : Colors.black,
              fontSize: size.height * 0.025,
            ),
          ),
          Row(
            children: [
              Padding(
                padding: EdgeInsets.symmetric(
                  vertical: size.height * 0.01,
                ),
                child: FaIcon(
                  FontAwesomeIcons.wind,
                  color: Colors.grey,
                  size: size.height * 0.03,
                ),
              ),
            ],
          ),
          Text(
            '$wind km/h',
            style: GoogleFonts.questrial(
              color: Colors.grey,
              fontSize: size.height * 0.02,
            ),
          ),
          Row(
            children: [
              Padding(
                padding: EdgeInsets.symmetric(
                  vertical: size.height * 0.01,
                ),
                child: FaIcon(
                  FontAwesomeIcons.umbrella,
                  color: Colors.blue,
                  size: size.height * 0.03,
                ),
              ),
            ],
          ),
          Text(
            '$rainChance %',
            style: GoogleFonts.questrial(
              color: Colors.blue,
              fontSize: size.height * 0.02,
            ),
          ),
        ],
      ),
    );
  }

  Widget buildSevenDayForecast(String time, int minTemp, int maxTemp,
      IconData weatherIcon, size, bool isDarkMode) {
    return Padding(
      padding: EdgeInsets.all(
        size.height * 0.005,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            children: [
              Padding(
                padding: EdgeInsets.symmetric(
                  horizontal: size.width * 0.02,
                ),
                child: Text(
                  time,
                  style: GoogleFonts.questrial(
                    color: isDarkMode ? Colors.white : Colors.black,
                    fontSize: size.height * 0.025,
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsets.symmetric(
                  horizontal: size.width * 0.25,
                ),
                child: FaIcon(
                  weatherIcon,
                  color: isDarkMode ? Colors.white : Colors.black,
                  size: size.height * 0.03,
                ),
              ),
              Align(
                child: Padding(
                  padding: EdgeInsets.only(
                    left: size.width * 0.15,
                  ),
                  child: Text(
                    '$minTemp˚C',
                    style: GoogleFonts.questrial(
                      color: isDarkMode ? Colors.white38 : Colors.black38,
                      fontSize: size.height * 0.025,
                    ),
                  ),
                ),
              ),
              Align(
                alignment: Alignment.centerRight,
                child: Padding(
                  padding: EdgeInsets.symmetric(
                    horizontal: size.width * 0.05,
                  ),
                  child: Text(
                    '$maxTemp˚C',
                    style: GoogleFonts.questrial(
                      color: isDarkMode ? Colors.white : Colors.black,
                      fontSize: size.height * 0.025,
                    ),
                  ),
                ),
              ),
            ],
          ),
          Divider(
            color: isDarkMode ? Colors.white : Colors.black,
          ),
        ],
      ),
    );
  }
}
Widget sun=Container(height: 20,width: 20,decoration: BoxDecoration(color: Colors.orangeAccent,borderRadius: BorderRadius.all(Radius.circular(30))),);

